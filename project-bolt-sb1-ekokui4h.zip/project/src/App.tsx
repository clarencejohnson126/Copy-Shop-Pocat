import React, { useState } from 'react';
import { ChevronDown, MapPin, Clock, Phone, Mail, Star, Truck, Leaf, Award, BookOpen, Bookmark, ShieldCheck } from 'lucide-react';

// Komponenten
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import BindingOptions from './components/BindingOptions';
import Configurator from './components/Configurator';
import ProcessSteps from './components/ProcessSteps';
import ShippingOptions from './components/ShippingOptions';
import Reviews from './components/Reviews';
import AboutUs from './components/AboutUs';
import FAQ from './components/FAQ';
import Footer from './components/Footer';

function App() {
  const [configStep, setConfigStep] = useState<number | null>(null);
  
  const startConfigurator = () => {
    setConfigStep(1);
    const configuratorElement = document.getElementById('configurator');
    if (configuratorElement) {
      configuratorElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-white text-gray-800">
      <Navbar startConfigurator={startConfigurator} />
      <Hero startConfigurator={startConfigurator} />
      <BindingOptions startConfigurator={startConfigurator} />
      <Configurator step={configStep} setStep={setConfigStep} />
      <ProcessSteps />
      <ShippingOptions />
      <Reviews />
      <AboutUs />
      <FAQ />
      <Footer />
    </div>
  );
}

export default App;