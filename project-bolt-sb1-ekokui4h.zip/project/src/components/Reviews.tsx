import React from 'react';
import { Star, ChevronLeft, ChevronRight } from 'lucide-react';

const Reviews: React.FC = () => {
  const reviews = [
    {
      id: 1,
      name: 'Julia M.',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80',
      rating: 5,
      text: 'Meine Masterarbeit kam perfekt gebunden an! Die Hardcover-Bindung sieht super professionell aus und hat bei meiner Verteidigung viele Komplimente bekommen.',
      degree: 'Master in Wirtschaftswissenschaften',
    },
    {
      id: 2,
      name: 'Markus K.',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80',
      rating: 5,
      text: 'Schneller Service, tolle Qualität und faire Preise. Meine Bachelorarbeit wurde innerhalb eines Tages gedruckt und gebunden. Absolut empfehlenswert!',
      degree: 'Bachelor in Informatik',
    },
    {
      id: 3,
      name: 'Laura S.',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80',
      rating: 5,
      text: 'Die Beratung vor Ort in Heidelberg war super hilfreich. Das Team hat mir bei der Auswahl der richtigen Bindung geholfen und das Ergebnis ist wirklich toll.',
      degree: 'Promotion in Biologie',
    },
    {
      id: 4,
      name: 'Thomas B.',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80',
      rating: 4,
      text: 'Der Online-Konfigurator war einfach zu bedienen und die Lieferung kam pünktlich. Ein Stern Abzug, weil die Seiten leicht versetzt waren, aber immer noch sehr gut!',
      degree: 'Bachelor in Maschinenbau',
    },
    {
      id: 5,
      name: 'Sarah F.',
      avatar: 'https://images.unsplash.com/photo-1619895862022-09114b41f16f?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80',
      rating: 5,
      text: 'Toller Service! Habe kurzfristig meine Dissertation binden lassen und bin sehr zufrieden mit dem Ergebnis. Die goldene Prägung sieht besonders edel aus.',
      degree: 'Promotion in Psychologie',
    },
  ];

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }).map((_, index) => (
      <Star
        key={index}
        className={`w-5 h-5 ${index < rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
      />
    ));
  };

  const [activeIndex, setActiveIndex] = React.useState(0);
  const [touchStart, setTouchStart] = React.useState(0);
  const [touchEnd, setTouchEnd] = React.useState(0);

  const handlePrev = () => {
    setActiveIndex((prev) => (prev === 0 ? reviews.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setActiveIndex((prev) => (prev === reviews.length - 1 ? 0 : prev + 1));
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    if (touchStart - touchEnd > 50) {
      handleNext();
    }

    if (touchStart - touchEnd < -50) {
      handlePrev();
    }
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-10">
          <div className="flex items-center justify-center mb-4">
            <div className="flex">
              {renderStars(5)}
            </div>
            <span className="ml-2 text-xl font-bold">4.9/5</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Was unsere Kunden sagen</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Über 600 positive Google-Bewertungen sprechen für sich. Hier einige Stimmen unserer zufriedenen Kunden.
          </p>
        </div>
        
        <div className="relative max-w-4xl mx-auto"
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        >
          <div className="overflow-hidden">
            <div
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${activeIndex * 100}%)` }}
            >
              {reviews.map((review) => (
                <div key={review.id} className="w-full flex-shrink-0 px-4">
                  <div className="bg-white rounded-xl p-8 shadow-md">
                    <div className="flex items-center mb-6">
                      <img
                        src={review.avatar}
                        alt={review.name}
                        className="w-16 h-16 rounded-full object-cover mr-4"
                      />
                      <div>
                        <div className="flex items-center mb-1">
                          {renderStars(review.rating)}
                        </div>
                        <h3 className="font-bold text-lg">{review.name}</h3>
                        <p className="text-sm text-gray-500">{review.degree}</p>
                      </div>
                    </div>
                    <p className="text-gray-700 italic text-lg leading-relaxed mb-4">"{review.text}"</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <button
            onClick={handlePrev}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 bg-white rounded-full p-3 shadow-md hover:bg-gray-100 focus:outline-none z-10 hidden md:block"
          >
            <ChevronLeft className="text-gray-700" />
          </button>
          
          <button
            onClick={handleNext}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 bg-white rounded-full p-3 shadow-md hover:bg-gray-100 focus:outline-none z-10 hidden md:block"
          >
            <ChevronRight className="text-gray-700" />
          </button>
          
          <div className="flex justify-center mt-8 space-x-2">
            {reviews.map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveIndex(index)}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === activeIndex ? 'bg-green-600' : 'bg-gray-300'
                }`}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>
        
        <div className="flex justify-center mt-10">
          <a
            href="https://g.page/r/CUxxxxxxx/review"
            target="_blank"
            rel="noopener noreferrer"
            className="text-green-600 hover:text-green-700 font-medium flex items-center"
          >
            <Star className="mr-1" size={16} />
            Bewertung auf Google hinterlassen
          </a>
        </div>
      </div>
    </section>
  );
};

export default Reviews;