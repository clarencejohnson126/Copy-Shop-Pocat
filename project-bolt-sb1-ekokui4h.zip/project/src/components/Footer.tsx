import React from 'react';
import { Phone, Mail, MapPin, Clock, Facebook, Instagram, Linkedin } from 'lucide-react';
import logo from '../assets/logo.tsx';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center mb-4">
              {logo}
              <span className="ml-2 font-bold text-2xl">Pocat</span>
            </div>
            <p className="text-gray-400 mb-6">
              Dein Copyshop für hochwertige Bindungen und Drucke in Heidelberg und Schwetzingen.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Linkedin size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Kontakt</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <Phone className="mr-3 mt-1 text-green-500 flex-shrink-0" size={18} />
                <span>06221 / 123 456</span>
              </li>
              <li className="flex items-start">
                <Mail className="mr-3 mt-1 text-green-500 flex-shrink-0" size={18} />
                <span>info@pocat.de</span>
              </li>
              <li className="flex items-start">
                <MapPin className="mr-3 mt-1 text-green-500 flex-shrink-0" size={18} />
                <div>
                  <p>Heidelberg</p>
                  <p className="text-gray-400">Hauptstraße 123, 69117</p>
                </div>
              </li>
              <li className="flex items-start">
                <MapPin className="mr-3 mt-1 text-green-500 flex-shrink-0" size={18} />
                <div>
                  <p>Schwetzingen</p>
                  <p className="text-gray-400">Bahnhofstraße 45, 68723</p>
                </div>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Öffnungszeiten</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <Clock className="mr-3 mt-1 text-green-500 flex-shrink-0" size={18} />
                <div>
                  <p>Montag - Freitag</p>
                  <p className="text-gray-400">9:00 - 18:00 Uhr</p>
                </div>
              </li>
              <li className="flex items-start">
                <Clock className="mr-3 mt-1 text-green-500 flex-shrink-0" size={18} />
                <div>
                  <p>Samstag</p>
                  <p className="text-gray-400">10:00 - 14:00 Uhr</p>
                </div>
              </li>
              <li className="flex items-start">
                <Clock className="mr-3 mt-1 text-green-500 flex-shrink-0" size={18} />
                <div>
                  <p>Sonntag</p>
                  <p className="text-gray-400">Geschlossen</p>
                </div>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Service</h3>
            <ul className="space-y-2">
              <li>
                <a href="#binding-options" className="text-gray-400 hover:text-white transition-colors">Bindungsoptionen</a>
              </li>
              <li>
                <a href="#process" className="text-gray-400 hover:text-white transition-colors">Ablauf</a>
              </li>
              <li>
                <a href="#shipping" className="text-gray-400 hover:text-white transition-colors">Versandoptionen</a>
              </li>
              <li>
                <a href="#configurator" className="text-gray-400 hover:text-white transition-colors">Konfigurator</a>
              </li>
              <li>
                <a href="#faq" className="text-gray-400 hover:text-white transition-colors">FAQ</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">Datenschutz</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">Impressum</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">AGB</a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-gray-800 text-center text-gray-400 text-sm">
          <p>© {new Date().getFullYear()} Pocat Copyshop. Alle Rechte vorbehalten.</p>
          <p className="mt-2">
            <span className="text-green-500 font-medium">Print Green and Local</span> - Nachhaltigkeit und Qualität aus der Region.
          </p>
          <div className="mt-4 flex justify-center space-x-4">
            <img src="https://via.placeholder.com/50x30" alt="Visa" className="h-8" />
            <img src="https://via.placeholder.com/50x30" alt="Mastercard" className="h-8" />
            <img src="https://via.placeholder.com/50x30" alt="PayPal" className="h-8" />
            <img src="https://via.placeholder.com/50x30" alt="Sofort" className="h-8" />
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;