import React, { useState } from 'react';
import { ChevronDown, ChevronUp, HelpCircle } from 'lucide-react';

const FAQ: React.FC = () => {
  const faqs = [
    {
      id: 1,
      question: 'Wie lange dauert die Bindung meiner Abschlussarbeit?',
      answer: 'In unseren Filialen in Heidelberg und Schwetzingen können wir Hardcover-Bindungen innerhalb von 2-3 Stunden fertigstellen. Softcover- und Ringbindungen sind in der Regel innerhalb von 30-60 Minuten abholbereit. Bei hohem Aufkommen kann es zu längeren Wartezeiten kommen, daher empfehlen wir eine Vorbestellung über unseren Konfigurator.',
    },
    {
      id: 2,
      question: 'Welche Bindung ist für meine Abschlussarbeit am besten geeignet?',
      answer: 'Die beste Bindung hängt von verschiedenen Faktoren ab: den Vorgaben deiner Hochschule, der Art der Arbeit und persönlichen Vorlieben. Für Abschlussarbeiten wie Bachelor- und Masterarbeiten empfehlen wir Hardcover-Bindungen für ein professionelles Erscheinungsbild. Bei längeren Arbeiten wie Dissertationen ist ein Hardcover unerlässlich. Für Seminararbeiten oder Präsentationsunterlagen eignen sich Softcover oder Ringbindungen besser.',
    },
    {
      id: 3,
      question: 'Welches Dateiformat sollte ich für den Druck meiner Arbeit verwenden?',
      answer: 'Wir empfehlen, deine Arbeit als PDF-Datei hochzuladen. PDFs bewahren das Layout, die Schriftarten und Bilder unabhängig vom Betriebssystem. Achte darauf, dass alle Schriften eingebettet sind und Bilder eine Auflösung von mindestens 300 dpi haben. Für beste Ergebnisse sollte das Dokument im A4-Format mit entsprechenden Rändern (mindestens 2 cm) erstellt sein.',
    },
    {
      id: 4,
      question: 'Kann ich meine Arbeit auch farbig drucken lassen?',
      answer: 'Ja, wir bieten sowohl Schwarz-Weiß- als auch Farbdruck an. Du kannst im Konfigurator auswählen, ob du die gesamte Arbeit oder nur bestimmte Seiten (z.B. Diagramme, Grafiken) in Farbe drucken möchtest. Farbseiten sind etwas teurer als Schwarz-Weiß-Seiten, daher kann eine selektive Farbauswahl kostensparend sein.',
    },
    {
      id: 5,
      question: 'Bietet ihr Expressdruck und -bindung an?',
      answer: 'Ja, wir bieten einen Express-Service für dringende Abgaben an. In unseren Filialen können viele Bindungsarten innerhalb weniger Stunden fertiggestellt werden. Für Hardcover-Bindungen mit Express-Option garantieren wir eine Fertigstellung am selben Tag, wenn die Bestellung vor 11:00 Uhr eingeht. Ein Expressversand ist ebenfalls verfügbar.',
    },
    {
      id: 6,
      question: 'Welche Zahlungsmethoden akzeptiert ihr?',
      answer: 'Wir akzeptieren verschiedene Zahlungsmethoden: Kreditkarte (Visa, MasterCard), PayPal, Sofortüberweisung, Rechnung (für Firmenkunden nach Vereinbarung) sowie Barzahlung bei Abholung in unseren Filialen. Alle Online-Zahlungen werden sicher und verschlüsselt verarbeitet.',
    },
    {
      id: 7,
      question: 'Wie kann ich meine Bestellung verfolgen?',
      answer: 'Nach Aufgabe deiner Bestellung erhältst du eine Bestätigungs-E-Mail mit einer Bestellnummer. Mit dieser Nummer kannst du den Status deiner Bestellung auf unserer Website verfolgen oder telefonisch nachfragen. Bei Versandaufträgen senden wir dir zusätzlich eine Tracking-Nummer, sobald deine Arbeit verschickt wurde.',
    },
    {
      id: 8,
      question: 'Gibt es Vorgaben für die Prägung auf dem Einband?',
      answer: 'Für Hardcover-Bindungen bieten wir Prägungen in Gold, Silber, Kupfer, Weiß oder Schwarz an. Der Text sollte eine Mindestschriftgröße von 18pt haben. Die Prägung kann auf dem Buchrücken und/oder auf dem Einband erfolgen. Beachte, dass sehr lange Titel eventuell nicht vollständig auf dem Buchrücken Platz finden. Universitätslogos können ebenfalls geprägt werden, benötigen aber eine hochauflösende Vektordatei.',
    },
  ];

  const [openItem, setOpenItem] = useState<number | null>(null);

  const toggleItem = (id: number) => {
    setOpenItem(openItem === id ? null : id);
  };

  return (
    <section id="faq" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <HelpCircle className="mx-auto text-green-600 mb-4" size={40} />
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Häufig gestellte Fragen</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Hier findest du Antworten auf die häufigsten Fragen zu unseren Dienstleistungen.
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto divide-y divide-gray-200">
          {faqs.map((faq) => (
            <div key={faq.id} className="py-5">
              <button
                onClick={() => toggleItem(faq.id)}
                className="flex justify-between items-center w-full text-left focus:outline-none"
              >
                <h3 className="text-lg font-semibold text-gray-800">{faq.question}</h3>
                {openItem === faq.id ? (
                  <ChevronUp className="flex-shrink-0 text-green-600" />
                ) : (
                  <ChevronDown className="flex-shrink-0 text-gray-500" />
                )}
              </button>
              {openItem === faq.id && (
                <div className="mt-3 text-gray-600 leading-relaxed">
                  {faq.answer}
                </div>
              )}
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <p className="mb-6 text-gray-600">
            Hast du weitere Fragen? Kontaktiere uns gerne direkt!
          </p>
          <a
            href="mailto:info@pocat.de"
            className="inline-flex items-center justify-center px-6 py-3 bg-green-600 text-white font-medium rounded-md hover:bg-green-700 transition-colors"
          >
            Kontakt aufnehmen
          </a>
        </div>
      </div>
    </section>
  );
};

export default FAQ;