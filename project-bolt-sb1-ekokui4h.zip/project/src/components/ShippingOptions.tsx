import React from 'react';
import { Truck, Clock, MapPin, Package } from 'lucide-react';

const ShippingOptions: React.FC = () => {
  const shippingOptions = [
    {
      id: 'pickup',
      icon: <MapPin className="w-12 h-12 text-green-600 mb-4" />,
      title: 'Selbstabholung',
      description: 'Hole deine fertige Arbeit in einer unserer Filialen in Heidelberg oder Schwetzingen ab.',
      timeframe: 'Gleicher Tag oder nächster Werktag möglich',
      price: 'Kostenlos',
      highlight: false,
    },
    {
      id: 'standard',
      icon: <Truck className="w-12 h-12 text-green-600 mb-4" />,
      title: 'Standardversand',
      description: 'Deutschlandweiter Versand per DHL mit Sendungsverfolgung.',
      timeframe: '1-3 Werktage',
      price: '4,90 €',
      highlight: false,
    },
    {
      id: 'express',
      icon: <Package className="w-12 h-12 text-green-600 mb-4" />,
      title: 'Express-Versand',
      description: 'Schneller Versand für dringende Abgabetermine. Deutschlandweit am nächsten Werktag.',
      timeframe: 'Nächster Werktag (bis 12 Uhr)',
      price: '12,90 €',
      highlight: true,
    },
    {
      id: 'international',
      icon: <Clock className="w-12 h-12 text-green-600 mb-4" />,
      title: 'Internationaler Express',
      description: 'Weltweiter Expressversand für internationale Kunden.',
      timeframe: '2-5 Werktage (je nach Destination)',
      price: 'ab 19,90 €',
      highlight: false,
    },
  ];

  return (
    <section id="shipping" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Versandoptionen</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Deine fertige Arbeit schnell und sicher erhalten – wähle die passende Versandoption.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {shippingOptions.map((option) => (
            <div 
              key={option.id} 
              className={`bg-white rounded-xl p-6 flex flex-col h-full transition-all duration-300 hover:shadow-lg ${
                option.highlight 
                  ? 'border-2 border-green-500 shadow-md transform hover:-translate-y-1' 
                  : 'border border-gray-200 hover:-translate-y-1'
              }`}
            >
              {option.highlight && (
                <div className="bg-green-500 text-white text-sm font-medium py-1 px-3 rounded-full self-start mb-4">
                  Empfohlen
                </div>
              )}
              
              <div className="text-center mb-2">
                {option.icon}
                <h3 className="text-xl font-bold mb-2">{option.title}</h3>
              </div>
              
              <p className="text-gray-600 mb-4 flex-grow">{option.description}</p>
              
              <div className="mt-auto">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-gray-600">Lieferzeit:</span>
                  <span className="font-medium">{option.timeframe}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Kosten:</span>
                  <span className={`font-bold ${option.highlight ? 'text-green-600' : ''}`}>{option.price}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 bg-gray-50 p-6 rounded-lg max-w-3xl mx-auto">
          <h3 className="font-bold text-xl mb-3">Hinweise zum Versand</h3>
          <ul className="space-y-2 text-gray-700">
            <li className="flex items-start">
              <span className="text-green-500 mr-2">•</span>
              <span>Bestellungen, die vor 12 Uhr eingehen, werden in der Regel noch am selben Werktag bearbeitet.</span>
            </li>
            <li className="flex items-start">
              <span className="text-green-500 mr-2">•</span>
              <span>Der Express-Versand garantiert eine Zustellung am nächsten Werktag (Montag bis Freitag).</span>
            </li>
            <li className="flex items-start">
              <span className="text-green-500 mr-2">•</span>
              <span>Zu jeder Sendung erhältst du eine Tracking-Nummer zur Sendungsverfolgung.</span>
            </li>
            <li className="flex items-start">
              <span className="text-green-500 mr-2">•</span>
              <span>Unsere Verpackungen sind umweltfreundlich und recycelbar - getreu unserem Motto "Print Green and Local".</span>
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
};

export default ShippingOptions;