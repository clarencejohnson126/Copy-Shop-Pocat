import React from 'react';
import { ArrowRight } from 'lucide-react';

interface HeroProps {
  startConfigurator: () => void;
}

const Hero: React.FC<HeroProps> = ({ startConfigurator }) => {
  return (
    <section className="relative min-h-screen flex items-center justify-center bg-gray-900 text-white overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1532153975070-2e9ab71f1b14?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80" 
          alt="Library with books" 
          className="w-full h-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-green-900/80 to-gray-900/70"></div>
      </div>
      
      <div className="container mx-auto px-4 py-24 relative z-10 mt-16">
        <div className="max-w-3xl">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-4">
            Dein Lieblingscopyshop in Heidelberg und Schwetzingen
          </h1>
          <p className="text-xl md:text-2xl font-light mb-8 text-gray-200">
            Seit über 20 Jahren die erste Adresse für das Drucken und Binden von Abschlussarbeiten
          </p>
          
          <div className="mb-12">
            <h2 className="text-2xl md:text-3xl font-bold mb-3">Die Deadline ruft?</h2>
            <p className="text-xl md:text-2xl font-light mb-8">Wir haben die perfekte Bindung!</p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <button 
              onClick={startConfigurator}
              className="bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-md font-medium text-lg transition-colors shadow-lg flex items-center justify-center"
            >
              Jetzt konfigurieren
              <ArrowRight className="ml-2" size={20} />
            </button>
            <a
              href="#binding-options"
              className="border border-white hover:bg-white/10 text-white px-8 py-4 rounded-md font-medium text-lg transition-colors text-center"
            >
              Bindungsoptionen anzeigen
            </a>
          </div>
          
          <div className="mt-12 flex flex-wrap gap-6 text-center">
            <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg flex-1 min-w-[180px]">
              <div className="font-bold text-green-400 text-xl">Premium Qualität</div>
              <p className="text-gray-200">Hochwertige Bindeoptionen für jede Arbeit</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg flex-1 min-w-[180px]">
              <div className="font-bold text-green-400 text-xl">Nachhaltigkeit</div>
              <p className="text-gray-200">Print Green and Local</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg flex-1 min-w-[180px]">
              <div className="font-bold text-green-400 text-xl">Express-Service</div>
              <p className="text-gray-200">Weltweiter Expressversand</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;