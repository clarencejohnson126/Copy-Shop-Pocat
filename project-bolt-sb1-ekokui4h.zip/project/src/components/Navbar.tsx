import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, MapPin, Clock } from 'lucide-react';
import logo from '../assets/logo.tsx';

interface NavbarProps {
  startConfigurator: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ startConfigurator }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'}`}>
      <div className="hidden lg:block bg-green-700 text-white py-1">
        <div className="container mx-auto flex justify-between items-center text-sm">
          <div className="flex space-x-6">
            <div className="flex items-center">
              <MapPin size={14} className="mr-1" />
              <span>Heidelberg & Schwetzingen</span>
            </div>
            <div className="flex items-center">
              <Clock size={14} className="mr-1" />
              <span>Mo-Fr: 9:00-18:00, Sa: 10:00-14:00</span>
            </div>
          </div>
          <div className="flex items-center">
            <Phone size={14} className="mr-1" />
            <span>06221 / 123 456</span>
          </div>
        </div>
      </div>
      
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <a href="/" className="flex items-center">
              {logo}
              <span className={`ml-2 font-bold text-2xl ${isScrolled ? 'text-green-700' : 'text-white lg:text-green-700'}`}>Pocat</span>
            </a>
          </div>
          
          <nav className="hidden md:flex space-x-8 text-lg font-medium">
            <a href="#binding-options" className={`${isScrolled ? 'text-gray-800' : 'text-white lg:text-gray-800'} hover:text-green-600 transition-colors`}>Bindungen</a>
            <a href="#process" className={`${isScrolled ? 'text-gray-800' : 'text-white lg:text-gray-800'} hover:text-green-600 transition-colors`}>Ablauf</a>
            <a href="#shipping" className={`${isScrolled ? 'text-gray-800' : 'text-white lg:text-gray-800'} hover:text-green-600 transition-colors`}>Versand</a>
            <a href="#about" className={`${isScrolled ? 'text-gray-800' : 'text-white lg:text-gray-800'} hover:text-green-600 transition-colors`}>Über uns</a>
            <a href="#faq" className={`${isScrolled ? 'text-gray-800' : 'text-white lg:text-gray-800'} hover:text-green-600 transition-colors`}>FAQ</a>
          </nav>
          
          <div className="hidden md:block">
            <button 
              onClick={startConfigurator}
              className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-md font-medium transition-colors shadow-md"
            >
              Jetzt konfigurieren
            </button>
          </div>
          
          <button 
            className="md:hidden text-gray-800" 
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-white shadow-lg">
          <div className="container mx-auto px-4 py-3">
            <nav className="flex flex-col space-y-3">
              <a href="#binding-options" className="text-gray-800 hover:text-green-600 transition-colors py-2 border-b border-gray-100" onClick={() => setIsOpen(false)}>Bindungen</a>
              <a href="#process" className="text-gray-800 hover:text-green-600 transition-colors py-2 border-b border-gray-100" onClick={() => setIsOpen(false)}>Ablauf</a>
              <a href="#shipping" className="text-gray-800 hover:text-green-600 transition-colors py-2 border-b border-gray-100" onClick={() => setIsOpen(false)}>Versand</a>
              <a href="#about" className="text-gray-800 hover:text-green-600 transition-colors py-2 border-b border-gray-100" onClick={() => setIsOpen(false)}>Über uns</a>
              <a href="#faq" className="text-gray-800 hover:text-green-600 transition-colors py-2 border-b border-gray-100" onClick={() => setIsOpen(false)}>FAQ</a>
              <button 
                onClick={() => {
                  startConfigurator();
                  setIsOpen(false);
                }}
                className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-md font-medium transition-colors shadow-md w-full mt-2"
              >
                Jetzt konfigurieren
              </button>
              <div className="flex flex-col space-y-2 text-sm text-gray-600 py-2">
                <div className="flex items-center">
                  <MapPin size={14} className="mr-2" />
                  <span>Heidelberg & Schwetzingen</span>
                </div>
                <div className="flex items-center">
                  <Clock size={14} className="mr-2" />
                  <span>Mo-Fr: 9:00-18:00, Sa: 10:00-14:00</span>
                </div>
                <div className="flex items-center">
                  <Phone size={14} className="mr-2" />
                  <span>06221 / 123 456</span>
                </div>
              </div>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;