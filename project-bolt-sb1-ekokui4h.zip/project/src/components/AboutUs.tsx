import React from 'react';
import { Leaf, Award, Clock, MapPin } from 'lucide-react';

const AboutUs: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row gap-12 items-center">
          <div className="lg:w-1/2">
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1571867424485-38c85a9d2900?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80" 
                alt="Team von Pocat Copyshop" 
                className="rounded-lg shadow-xl w-full h-auto object-cover"
              />
              <div className="absolute -bottom-6 -right-6 bg-green-600 rounded-lg p-4 shadow-lg max-w-xs">
                <p className="text-white font-bold text-xl">Über 20 Jahre Erfahrung</p>
                <p className="text-green-100">Seit 2003 vertrauen uns Studenten ihre wichtigsten Arbeiten an.</p>
              </div>
            </div>
          </div>
          
          <div className="lg:w-1/2">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Über Pocat – Ihr Copyshop in Heidelberg und Schwetzingen</h2>
            <p className="text-xl text-gray-600 mb-6">
              Seit über 20 Jahren sind wir die erste Adresse für das Drucken und Binden von Abschlussarbeiten.
              Mit unserer Expertise und Leidenschaft unterstützen wir Studierende und Akademiker dabei, 
              ihre Arbeiten in bester Qualität zu präsentieren.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="bg-gray-50 p-5 rounded-lg">
                <Leaf className="text-green-600 mb-3" size={28} />
                <h3 className="text-xl font-bold mb-2">Nachhaltigkeit</h3>
                <p className="text-gray-600">
                  "Print Green and Local" ist nicht nur ein Slogan, sondern unser Versprechen. Wir verwenden Premiumpapier aus nachhaltiger Herstellung.
                </p>
              </div>
              
              <div className="bg-gray-50 p-5 rounded-lg">
                <Award className="text-green-600 mb-3" size={28} />
                <h3 className="text-xl font-bold mb-2">Qualität</h3>
                <p className="text-gray-600">
                  Höchste Druck- und Bindequalität ist unser Anspruch. Wir arbeiten mit modernster Technologie und besten Materialien.
                </p>
              </div>
            </div>
            
            <p className="text-gray-600 mb-6">
              Als lokales Unternehmen unterstützen wir die Region und bieten persönlichen Service, den unsere Kunden zu schätzen wissen. 
              Nachhaltigkeit und Qualität stehen bei uns im Mittelpunkt jedes Auftrags.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-start">
                <MapPin className="text-green-600 mt-1 mr-3" size={20} />
                <div>
                  <h4 className="font-bold">Heidelberg</h4>
                  <p className="text-gray-600">Hauptstraße 123<br />69117 Heidelberg</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <MapPin className="text-green-600 mt-1 mr-3" size={20} />
                <div>
                  <h4 className="font-bold">Schwetzingen</h4>
                  <p className="text-gray-600">Bahnhofstraße 45<br />68723 Schwetzingen</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <Clock className="text-green-600 mt-1 mr-3" size={20} />
                <div>
                  <h4 className="font-bold">Öffnungszeiten</h4>
                  <p className="text-gray-600">Mo-Fr: 9:00-18:00<br />Sa: 10:00-14:00</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-20 text-center">
          <h3 className="text-2xl font-bold mb-8">Unsere Partner & Kooperationen</h3>
          <div className="flex flex-wrap justify-center items-center gap-8 opacity-70">
            <div className="w-32 h-20 bg-gray-200 rounded flex items-center justify-center">Uni Heidelberg</div>
            <div className="w-32 h-20 bg-gray-200 rounded flex items-center justify-center">DHBW Mannheim</div>
            <div className="w-32 h-20 bg-gray-200 rounded flex items-center justify-center">SRH Hochschule</div>
            <div className="w-32 h-20 bg-gray-200 rounded flex items-center justify-center">PH Heidelberg</div>
            <div className="w-32 h-20 bg-gray-200 rounded flex items-center justify-center">Hochschule Mannheim</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutUs;