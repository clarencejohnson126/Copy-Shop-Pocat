import React from 'react';
import { Check } from 'lucide-react';

interface BindingOptionsProps {
  startConfigurator: () => void;
}

const BindingOptions: React.FC<BindingOptionsProps> = ({ startConfigurator }) => {
  const bindings = [
    {
      id: 'hardcover',
      name: 'Hardcover',
      description: 'Stabile, langlebige Bindung mit festem Einband',
      price: 'ab 19,90 €',
      image: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      features: [
        'Premium Qualität',
        'Edler und hochwertiger Look',
        'Perfekt für Abschlussarbeiten',
        'Verschiedene Farben verfügbar',
      ],
      popular: true,
    },
    {
      id: 'softcover',
      name: 'Softcover',
      description: 'Flexible, leichte Bindung mit dünnem Einband',
      price: 'ab 12,90 €',
      image: 'https://images.unsplash.com/photo-1589998059171-988d887df646?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      features: [
        'Kostengünstige Alternative',
        'Leichtere Handhabung',
        'Ideal für Berichte',
        'Schnelle Produktion',
      ],
      popular: false,
    },
    {
      id: 'metalring',
      name: 'Metall Ringbuch',
      description: 'Flexible Bindung mit stabilen Metallringen',
      price: 'ab 9,90 €',
      image: 'https://images.unsplash.com/photo-1519791883288-dc8bd696e667?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      features: [
        'Einfaches Umblättern',
        'Komplett aufklappbar',
        'Langlebig und robust',
        'Ideal für Präsentationen',
      ],
      popular: false,
    },
    {
      id: 'plasticring',
      name: 'Plastik Ringbuch',
      description: 'Stabile, geschlossene Bindung mit Kunststoffringen',
      price: 'ab 7,90 €',
      image: 'https://images.unsplash.com/photo-1456735190827-d1262f71b8a3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      features: [
        'Günstigste Option',
        'Schnelle Fertigstellung',
        'Verschiedene Farben',
        'Ideal für Dokumentationen',
      ],
      popular: false,
    },
  ];

  return (
    <section id="binding-options" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Unsere Bindungsoptionen</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Wähle aus verschiedenen Bindungsarten für deine Arbeit – von der klassischen Hardcover-Bindung bis hin zur flexiblen Ringbindung.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {bindings.map((binding) => (
            <div 
              key={binding.id} 
              className={`bg-white rounded-xl shadow-lg overflow-hidden transform transition-all duration-300 hover:shadow-xl hover:-translate-y-1 relative flex flex-col ${binding.popular ? 'border-2 border-green-500' : ''}`}
            >
              {binding.popular && (
                <div className="absolute top-4 right-4 bg-green-500 text-white px-3 py-1 rounded-full text-sm font-medium z-10">
                  Beliebt
                </div>
              )}
              <div className="h-48 overflow-hidden">
                <img 
                  src={binding.image} 
                  alt={binding.name} 
                  className="w-full h-full object-cover transform transition-transform duration-500 hover:scale-110"
                />
              </div>
              <div className="p-6 flex-1 flex flex-col">
                <h3 className="text-xl font-bold mb-2">{binding.name}</h3>
                <p className="text-gray-600 mb-4">{binding.description}</p>
                <div className="text-2xl font-bold text-green-600 mb-4">{binding.price}</div>
                <ul className="mb-6 flex-1">
                  {binding.features.map((feature, index) => (
                    <li key={index} className="flex items-start mb-2">
                      <Check className="text-green-500 mr-2 flex-shrink-0 mt-0.5" size={18} />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <button
                  onClick={startConfigurator}
                  className={`w-full py-3 rounded-md font-medium transition-colors 
                    ${binding.popular 
                      ? 'bg-green-600 hover:bg-green-700 text-white' 
                      : 'bg-gray-100 hover:bg-gray-200 text-gray-800'}`}
                >
                  Auswählen
                </button>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <p className="text-lg text-gray-600 mb-6">
            Unsicher, welche Bindung am besten zu deiner Arbeit passt? 
            Kontaktiere uns für eine persönliche Beratung!
          </p>
          <button
            onClick={startConfigurator}
            className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 rounded-md font-medium transition-colors shadow-md"
          >
            Zum Konfigurator
          </button>
        </div>
      </div>
    </section>
  );
};

export default BindingOptions;