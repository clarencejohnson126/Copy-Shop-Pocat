import React, { useState, useEffect } from 'react';
import { ArrowLeft, ArrowRight, Check, Upload, Palette, BookOpen, Truck, AlertCircle } from 'lucide-react';

interface ConfiguratorProps {
  step: number | null;
  setStep: React.Dispatch<React.SetStateAction<number | null>>;
}

interface BindingOption {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
}

interface PaperOption {
  id: string;
  name: string;
  description: string;
  pricePerPage: number;
}

interface Extra {
  id: string;
  name: string;
  description: string;
  price: number;
}

interface ColorOption {
  id: string;
  name: string;
  color: string;
}

interface EmbossingColor {
  id: string;
  name: string;
  color: string;
}

const Configurator: React.FC<ConfiguratorProps> = ({ step, setStep }) => {
  // Binding options
  const bindingOptions: BindingOption[] = [
    {
      id: 'hardcover',
      name: 'Hardcover',
      description: 'Stabile, langlebige Bindung mit festem Einband',
      price: 19.90,
      image: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    },
    {
      id: 'softcover',
      name: 'Softcover',
      description: 'Flexible, leichte Bindung mit dünnem Einband',
      price: 12.90,
      image: 'https://images.unsplash.com/photo-1589998059171-988d887df646?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    },
    {
      id: 'metalring',
      name: 'Metall Ringbuch',
      description: 'Flexible Bindung mit stabilen Metallringen',
      price: 9.90,
      image: 'https://images.unsplash.com/photo-1519791883288-dc8bd696e667?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    },
    {
      id: 'plasticring',
      name: 'Plastik Ringbuch',
      description: 'Stabile, geschlossene Bindung mit Kunststoffringen',
      price: 7.90,
      image: 'https://images.unsplash.com/photo-1456735190827-d1262f71b8a3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    },
  ];

  // Paper options
  const paperOptions: PaperOption[] = [
    {
      id: 'standard',
      name: '80g/m² Standardpapier',
      description: 'Leichtes Papier, ideal für umfangreiche Arbeiten',
      pricePerPage: 0.05,
    },
    {
      id: 'premium',
      name: '120g/m² Premiumpapier',
      description: 'Hochwertiges Papier für eine edle Optik',
      pricePerPage: 0.08,
    },
  ];

  // Extras
  const extras: Extra[] = [
    {
      id: 'bookmark',
      name: 'Lesezeichen',
      description: 'Praktisches Lesezeichen für deine Arbeit',
      price: 2.50,
    },
    {
      id: 'corners',
      name: 'Buchecken',
      description: 'Schützende Ecken für längere Haltbarkeit',
      price: 3.90,
    },
    {
      id: 'uvCoating',
      name: 'UV-Beschichtung',
      description: 'Schützt den Einband vor Verschmutzungen',
      price: 4.50,
    },
  ];

  // Cover colors
  const coverColors: ColorOption[] = [
    { id: 'black', name: 'Schwarz', color: '#000000' },
    { id: 'darkblue', name: 'Dunkelblau', color: '#14213d' },
    { id: 'darkgreen', name: 'Dunkelgrün', color: '#1b4332' },
    { id: 'burgundy', name: 'Bordeauxrot', color: '#641220' },
    { id: 'gray', name: 'Grau', color: '#6c757d' },
  ];

  // Embossing colors
  const embossingColors: EmbossingColor[] = [
    { id: 'gold', name: 'Gold', color: '#ffd700' },
    { id: 'silver', name: 'Silber', color: '#c0c0c0' },
    { id: 'copper', name: 'Kupfer', color: '#b87333' },
    { id: 'white', name: 'Weiß', color: '#ffffff' },
    { id: 'black', name: 'Schwarz', color: '#000000' },
  ];

  // State for user selections
  const [selectedBinding, setSelectedBinding] = useState<string>('hardcover');
  const [pageCount, setPageCount] = useState<number>(80);
  const [selectedPaper, setSelectedPaper] = useState<string>('standard');
  const [selectedExtras, setSelectedExtras] = useState<string[]>([]);
  const [copies, setCopies] = useState<number>(1);
  const [selectedCoverColor, setSelectedCoverColor] = useState<string>('black');
  const [selectedEmbossingColor, setSelectedEmbossingColor] = useState<string>('gold');
  const [embossingText, setEmbossingText] = useState<string>('');
  const [file, setFile] = useState<File | null>(null);
  const [logoFile, setLogoFile] = useState<File | null>(null);

  // Calculated values
  const [totalPrice, setTotalPrice] = useState<number>(0);

  // Calculate total price
  useEffect(() => {
    if (step === null) return;
    
    let price = 0;
    
    // Binding price
    const binding = bindingOptions.find(b => b.id === selectedBinding);
    if (binding) {
      price += binding.price;
    }
    
    // Paper price
    const paper = paperOptions.find(p => p.id === selectedPaper);
    if (paper) {
      price += paper.pricePerPage * pageCount;
    }
    
    // Extras price
    selectedExtras.forEach(extraId => {
      const extra = extras.find(e => e.id === extraId);
      if (extra) {
        price += extra.price;
      }
    });
    
    // Multiply by copies
    price *= copies;
    
    // Round to 2 decimal places
    price = Math.round(price * 100) / 100;
    
    setTotalPrice(price);
  }, [step, selectedBinding, pageCount, selectedPaper, selectedExtras, copies, bindingOptions, paperOptions, extras]);

  if (step === null) {
    return null;
  }

  return (
    <section id="configurator" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Konfiguriere deine Abschlussarbeit</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            In wenigen Schritten zur perfekten Bindung für deine Arbeit.
          </p>
        </div>
        
        {/* Progress Steps */}
        <div className="flex justify-between items-center mb-10 max-w-3xl mx-auto">
          {[1, 2, 3, 4].map((stepNumber) => (
            <React.Fragment key={stepNumber}>
              <div 
                className={`flex flex-col items-center ${stepNumber < step ? 'cursor-pointer' : ''}`}
                onClick={() => stepNumber < step ? setStep(stepNumber) : null}
              >
                <div className={`
                  w-10 h-10 rounded-full flex items-center justify-center text-lg font-semibold mb-2
                  ${step > stepNumber 
                    ? 'bg-green-600 text-white' 
                    : step === stepNumber 
                      ? 'bg-green-600 text-white' 
                      : 'bg-gray-200 text-gray-600'}
                `}>
                  {step > stepNumber ? <Check size={20} /> : stepNumber}
                </div>
                <div className={`text-sm font-medium ${step === stepNumber ? 'text-green-600' : 'text-gray-600'}`}>
                  {stepNumber === 1 && 'Bindung'}
                  {stepNumber === 2 && 'Details'}
                  {stepNumber === 3 && 'Cover'}
                  {stepNumber === 4 && 'Upload'}
                </div>
              </div>
              
              {stepNumber < 4 && (
                <div className={`flex-1 h-0.5 ${step > stepNumber ? 'bg-green-600' : 'bg-gray-200'}`}></div>
              )}
            </React.Fragment>
          ))}
        </div>
        
        {/* Configuration Content */}
        <div className="bg-gray-50 rounded-xl p-6 mb-8 max-w-5xl mx-auto shadow-md">
          {/* Step 1: Binding Selection */}
          {step === 1 && (
            <div>
              <h3 className="text-2xl font-bold mb-6 flex items-center">
                <BookOpen className="mr-2" size={24} />
                Bindung auswählen
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                {bindingOptions.map((binding) => (
                  <div 
                    key={binding.id}
                    onClick={() => setSelectedBinding(binding.id)}
                    className={`
                      bg-white rounded-lg p-4 cursor-pointer transition-all transform hover:-translate-y-1 hover:shadow-lg border-2
                      ${selectedBinding === binding.id ? 'border-green-500 shadow-md' : 'border-transparent'}
                    `}
                  >
                    <div className="flex">
                      <div className="w-24 h-24 overflow-hidden rounded-md mr-4 flex-shrink-0">
                        <img 
                          src={binding.image} 
                          alt={binding.name} 
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <h4 className="text-lg font-semibold mb-1">{binding.name}</h4>
                        <p className="text-gray-600 text-sm mb-2">{binding.description}</p>
                        <div className="text-xl font-bold text-green-600">{binding.price.toFixed(2)} €</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Step 2: Configure Details */}
          {step === 2 && (
            <div>
              <h3 className="text-2xl font-bold mb-6 flex items-center">
                <BookOpen className="mr-2" size={24} />
                Abschlussarbeit konfigurieren
              </h3>
              
              {/* Page Count */}
              <div className="mb-8">
                <label className="block text-lg font-medium mb-2">Seitenanzahl</label>
                <div className="flex items-center">
                  <input 
                    type="range" 
                    min="1" 
                    max="500" 
                    value={pageCount} 
                    onChange={(e) => setPageCount(parseInt(e.target.value))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer mr-4"
                  />
                  <input 
                    type="number" 
                    min="1" 
                    max="500" 
                    value={pageCount} 
                    onChange={(e) => setPageCount(parseInt(e.target.value))}
                    className="w-20 px-3 py-2 border border-gray-300 rounded-md text-center"
                  />
                </div>
                <p className="text-sm text-gray-500 mt-1">Anzahl der zu druckenden Seiten</p>
              </div>
              
              {/* Paper Quality */}
              <div className="mb-8">
                <label className="block text-lg font-medium mb-2">Papierqualität</label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {paperOptions.map((paper) => (
                    <div 
                      key={paper.id}
                      onClick={() => setSelectedPaper(paper.id)}
                      className={`
                        bg-white rounded-lg p-4 cursor-pointer transition-all border-2
                        ${selectedPaper === paper.id ? 'border-green-500 shadow-md' : 'border-transparent'}
                      `}
                    >
                      <div className="flex items-center">
                        <div className={`w-5 h-5 rounded-full border-2 mr-3 flex items-center justify-center ${selectedPaper === paper.id ? 'border-green-500' : 'border-gray-300'}`}>
                          {selectedPaper === paper.id && <div className="w-3 h-3 bg-green-500 rounded-full"></div>}
                        </div>
                        <div>
                          <h4 className="font-medium">{paper.name}</h4>
                          <p className="text-gray-600 text-sm">{paper.description}</p>
                          <p className="text-green-600 font-medium">{paper.pricePerPage.toFixed(2)} € pro Seite</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Extras */}
              <div className="mb-8">
                <label className="block text-lg font-medium mb-2">Extras (optional)</label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {extras.map((extra) => (
                    <div 
                      key={extra.id}
                      onClick={() => {
                        if (selectedExtras.includes(extra.id)) {
                          setSelectedExtras(selectedExtras.filter(id => id !== extra.id));
                        } else {
                          setSelectedExtras([...selectedExtras, extra.id]);
                        }
                      }}
                      className={`
                        bg-white rounded-lg p-4 cursor-pointer transition-all border-2
                        ${selectedExtras.includes(extra.id) ? 'border-green-500 shadow-md' : 'border-transparent'}
                      `}
                    >
                      <div className="flex items-start">
                        <div className={`w-5 h-5 mt-0.5 border-2 mr-3 flex items-center justify-center ${selectedExtras.includes(extra.id) ? 'bg-green-500 border-green-500' : 'border-gray-300'}`}>
                          {selectedExtras.includes(extra.id) && <Check size={14} className="text-white" />}
                        </div>
                        <div>
                          <h4 className="font-medium">{extra.name}</h4>
                          <p className="text-gray-600 text-sm">{extra.description}</p>
                          <p className="text-green-600 font-medium">+ {extra.price.toFixed(2)} €</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Number of Copies */}
              <div className="mb-4">
                <label className="block text-lg font-medium mb-2">Anzahl der Exemplare</label>
                <div className="flex max-w-xs">
                  <button 
                    className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-l-md"
                    onClick={() => setCopies(Math.max(1, copies - 1))}
                  >
                    -
                  </button>
                  <input 
                    type="number" 
                    min="1" 
                    value={copies} 
                    onChange={(e) => setCopies(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-20 px-3 py-2 border-t border-b border-gray-300 text-center"
                  />
                  <button 
                    className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-r-md"
                    onClick={() => setCopies(copies + 1)}
                  >
                    +
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {/* Step 3: Cover Design */}
          {step === 3 && (
            <div>
              <h3 className="text-2xl font-bold mb-6 flex items-center">
                <Palette className="mr-2" size={24} />
                Cover gestalten
              </h3>
              
              {/* Cover Color */}
              <div className="mb-8">
                <label className="block text-lg font-medium mb-2">Farbe des Einbands</label>
                <div className="flex flex-wrap gap-3">
                  {coverColors.map((color) => (
                    <div 
                      key={color.id}
                      onClick={() => setSelectedCoverColor(color.id)}
                      className={`
                        w-16 h-16 rounded-full cursor-pointer transition-transform flex items-center justify-center
                        ${selectedCoverColor === color.id ? 'ring-4 ring-green-400 scale-110' : ''}
                      `}
                      style={{ backgroundColor: color.color }}
                    >
                      {selectedCoverColor === color.id && color.id !== 'black' && (
                        <Check size={24} className="text-white" />
                      )}
                      {selectedCoverColor === color.id && color.id === 'black' && (
                        <Check size={24} className="text-white" />
                      )}
                    </div>
                  ))}
                </div>
                <p className="text-sm text-gray-500 mt-2">
                  Ausgewählt: {coverColors.find(c => c.id === selectedCoverColor)?.name}
                </p>
              </div>
              
              {/* Uni Logo */}
              <div className="mb-8">
                <label className="block text-lg font-medium mb-2">Uni-Logo (optional)</label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                  <div className="flex items-center justify-center">
                    <Upload className="mr-2 text-gray-500" />
                    <span className="text-gray-500">Logo hier hochladen</span>
                  </div>
                  <p className="text-sm text-gray-500 mt-2">PNG oder JPG, hochauflösend (min. 300 dpi)</p>
                  <input 
                    type="file" 
                    accept=".png,.jpg,.jpeg" 
                    onChange={(e) => e.target.files && setLogoFile(e.target.files[0])}
                    className="mt-4 w-full"
                  />
                </div>
              </div>
              
              {/* Embossing Color */}
              <div className="mb-8">
                <label className="block text-lg font-medium mb-2">Prägungsfarbe</label>
                <div className="flex flex-wrap gap-3">
                  {embossingColors.map((color) => (
                    <div 
                      key={color.id}
                      onClick={() => setSelectedEmbossingColor(color.id)}
                      className={`
                        w-12 h-12 rounded-full cursor-pointer transition-transform border
                        ${selectedEmbossingColor === color.id ? 'ring-4 ring-green-400 scale-110' : ''}
                        ${color.id === 'white' ? 'border-gray-300' : 'border-transparent'}
                      `}
                      style={{ backgroundColor: color.color }}
                    >
                      {selectedEmbossingColor === color.id && color.id !== 'white' && color.id !== 'black' && (
                        <Check size={18} className="text-black m-auto" />
                      )}
                      {selectedEmbossingColor === color.id && color.id === 'white' && (
                        <Check size={18} className="text-black m-auto" />
                      )}
                      {selectedEmbossingColor === color.id && color.id === 'black' && (
                        <Check size={18} className="text-white m-auto" />
                      )}
                    </div>
                  ))}
                </div>
                <p className="text-sm text-gray-500 mt-2">
                  Ausgewählt: {embossingColors.find(c => c.id === selectedEmbossingColor)?.name}
                </p>
              </div>
              
              {/* Embossing Text */}
              <div className="mb-4">
                <label className="block text-lg font-medium mb-2">Prägungstext</label>
                <textarea 
                  rows={3}
                  placeholder="Titel der Arbeit, Name, etc. (min. 18pt Schriftgröße)"
                  value={embossingText}
                  onChange={(e) => setEmbossingText(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg"
                />
                <p className="text-sm text-gray-500 mt-1">
                  <AlertCircle className="inline mr-1" size={14} />
                  Nur Titelseite und Rücken werden geprägt. Mindestschriftgröße: 18pt.
                </p>
              </div>
            </div>
          )}
          
          {/* Step 4: File Upload */}
          {step === 4 && (
            <div>
              <h3 className="text-2xl font-bold mb-6 flex items-center">
                <Upload className="mr-2" size={24} />
                Datei hochladen
              </h3>
              
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center mb-8">
                <div className="flex flex-col items-center justify-center">
                  <Upload className="text-gray-500 mb-3" size={40} />
                  <h4 className="text-xl font-medium mb-2">Druckdaten hochladen</h4>
                  <p className="text-gray-500 mb-4">PDF-Datei mit deiner Abschlussarbeit hochladen</p>
                  <input 
                    type="file" 
                    accept=".pdf" 
                    onChange={(e) => e.target.files && setFile(e.target.files[0])}
                    className="mb-4"
                  />
                  <p className="text-sm text-gray-500">
                    Max. 500 MB · PDF-Format · Eine einzelne Datei
                  </p>
                </div>
              </div>
              
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-8">
                <h4 className="text-lg font-medium text-blue-800 mb-2 flex items-center">
                  <AlertCircle className="mr-2" size={20} />
                  Wichtige Hinweise zur Druckdatei
                </h4>
                <ul className="list-disc list-inside space-y-1 text-blue-700">
                  <li>Stelle sicher, dass deine PDF-Datei druckfertig ist</li>
                  <li>Überprüfe Seitenformat und Ausrichtung (A4, hochkant)</li>
                  <li>Achte auf ausreichende Auflösung bei Bildern (min. 300 dpi)</li>
                  <li>Bei Fragen kannst du uns jederzeit kontaktieren</li>
                </ul>
              </div>
            </div>
          )}
          
          {/* Price and Actions */}
          <div className="flex flex-col md:flex-row justify-between items-center mt-10 pt-6 border-t border-gray-200">
            <div className="mb-4 md:mb-0">
              <div className="text-gray-600">Gesamtpreis:</div>
              <div className="text-3xl font-bold text-green-600">{totalPrice.toFixed(2)} €</div>
              <div className="text-sm text-gray-500">inkl. MwSt.</div>
            </div>
            
            <div className="flex space-x-4">
              {step > 1 && (
                <button
                  onClick={() => setStep(step - 1)}
                  className="flex items-center px-6 py-3 border border-gray-300 rounded-md font-medium text-gray-700 hover:bg-gray-50"
                >
                  <ArrowLeft className="mr-2" size={18} />
                  Zurück
                </button>
              )}
              
              {step < 4 ? (
                <button
                  onClick={() => setStep(step + 1)}
                  className="flex items-center px-6 py-3 bg-green-600 rounded-md font-medium text-white hover:bg-green-700"
                >
                  Weiter
                  <ArrowRight className="ml-2" size={18} />
                </button>
              ) : (
                <button
                  onClick={() => console.log('Order placed')}
                  className="flex items-center px-6 py-3 bg-green-600 rounded-md font-medium text-white hover:bg-green-700"
                >
                  Bestellung abschließen
                  <Check className="ml-2" size={18} />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Configurator;